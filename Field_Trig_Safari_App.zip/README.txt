FIELD TRIG CLASSROOM — SAFARI VERSION

Best use on iPhone:
1. Put these files on any simple web host or open index.html from a hosted link.
2. In Safari, tap Share.
3. Choose "Add to Home Screen".
4. It will then open like a standalone app.

Files:
- index.html
- manifest.webmanifest
- sw.js

The app includes:
- Home dashboard
- Lesson 1
- Interactive Triangle Lab
- Practice quiz
- Saved XP/progress with localStorage
- PWA/service worker support for installation/offline use once hosted
